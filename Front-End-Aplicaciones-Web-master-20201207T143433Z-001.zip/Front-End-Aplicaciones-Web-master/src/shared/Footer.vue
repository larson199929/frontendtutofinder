<template>
  <!-- Hero footer: will stick at the bottom -->
  <div class="hero-foot has-text-centered">
    <section class="section">
      <div class="container">
        <p>
          <b>TUTOFINDER APP</b> - desarrollado para el curso de Aplicaciones Web
        </p>
      </div>
    </section>
  </div>
</template>
