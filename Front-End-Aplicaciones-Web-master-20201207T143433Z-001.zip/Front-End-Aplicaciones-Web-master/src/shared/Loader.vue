<template>
  <div class="has-text-centered is-loading fa-1x has-text-info">
    <div class="fa-3x">
      <i class="fas fa-cog fa-spin"></i>
    </div>
  </div>
</template>